import sys


def get_argument_value_from_argvs(argument: str):
    """
    Example of usage:
    >>> sys.argv = ['locust', '-f', 'locustfile_nfs.py', '-c', '10', '-r', '10', '--no-web', '-t', '30']
    >>> get_argument_value_from_argvs('-r')
    >>> 10
    """
    args = sys.argv
    try:
        index = args.index(argument)
    except (LookupError, ValueError):
        return None
    else:
        return args[index + 1]
