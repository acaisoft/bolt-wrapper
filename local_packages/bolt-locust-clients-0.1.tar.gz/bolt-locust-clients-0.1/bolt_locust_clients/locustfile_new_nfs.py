import os

from locust import TaskSet, task

from clients import QuestFileSystemLocust
from enums import FileSizeEnum

MIN_WAIT = int(os.getenv('MIN_WAIT', '100'))
MAX_WAIT = int(os.getenv('MAX_WAIT', '200'))


class QuestTaskSet(TaskSet):
    @task(10)
    def send_small_file(self):
        self.client.write('File with size 1', FileSizeEnum.SIZE_1)

    @task(5)
    def send_normal_file(self):
        self.client.write('File with size 10', FileSizeEnum.SIZE_10)

    @task(1)
    def send_big_file(self):
        self.client.write('File with size 100', FileSizeEnum.SIZE_100)

    @task(3)
    def send_normal_file(self):
        self.client.send('File with size 10', FileSizeEnum.SIZE_10)

    @task(1)
    def generate_small_ddt(self):
        self.client.ddt('Small ddt', {'filename': 'small_ddt', 'filesize': '10', 'blocksize': '8'})


class FileSystemUser(QuestFileSystemLocust):
    nfs_host = '192.168.1.201'
    container_name = 'aaa'
    min_wait = MIN_WAIT
    max_wait = MAX_WAIT
    task_set = QuestTaskSet
