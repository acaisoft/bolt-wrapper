from subprocess import check_call, check_output, PIPE, STDOUT

try:
    result = check_call('cp utails.py art.py', shell=True)
except Exception as ex:
    import ipdb; ipdb.set_trace()
    print(f'ex: {ex}')
else:
    print(f'res: {result}')
