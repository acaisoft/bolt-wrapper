import os
import sys
import time
import json
import asyncio
import aiohttp
import requests
import logging

QUEST_USERNAME = os.getenv('QUEST_USERNAME')
QUEST_PASSWORD = os.getenv('QUEST_PASSWORD')
QUEST_API_SCHEME = os.getenv('QUEST_API_SCHEME')
QUEST_API_HOST = os.getenv('QUEST_API_HOST')
QUEST_API_PORT = os.getenv('QUEST_API_PORT')
CONTAINER_NAME = os.getenv('CONTAINER_NAME')
SENDING_INTERVAL_IN_SECONDS = int(os.getenv('SENDING_INTERVAL_IN_SECONDS', '2'))

absolute_dir_path = os.path.dirname(__file__)


def get_argument_value_from_argvs(argument: str):
    """
    Example of usage:
    >>> sys.argv = ['locust', '-f', 'locustfile_nfs.py', '-c', '10', '-r', '10', '--no-web', '-t', '30']
    >>> get_argument_value_from_argvs('-r')
    >>> 10
    """
    args = sys.argv
    try:
        index = args.index(argument)
    except (LookupError, ValueError):
        return None
    else:
        return args[index + 1]


def setup_custom_logger(name=None):
    formatter = logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    return logger


logger = setup_custom_logger(__name__)


class Stats(object):
    single_stats = {}
    dynamically_stats = {}
    start = None
    finish = None
    jwt_token = None
    duration = 60

    def __init__(self):
        duration = get_argument_value_from_argvs('--duration')
        if duration is not None:
            self.duration = float(duration)
        self.start = time.time()
        self.finish = self.start + self.duration
        self.base_url = f'{QUEST_API_SCHEME}://{QUEST_API_HOST}:{QUEST_API_PORT}'
        self.auth()
        self.headers = {'Authorization': f'Bearer {self.jwt_token}'}

    def auth(self):
        url = f'{self.base_url}/api/auth/login'
        response = requests.post(url, json={'name': QUEST_USERNAME, 'password': QUEST_PASSWORD}, verify=False)
        self.jwt_token = response.json()['JWT_TOKEN']

    def save_and_exit(self):
        with open('single_stats.txt', 'w') as outfile:
            json.dump(self.single_stats, outfile)
            logger.info(f'Successfully aggregated single stats {self.single_stats}')

        with open('dynamically_stats.txt', 'w') as outfile:
            json.dump(self.dynamically_stats, outfile)
            logger.info(f'Successfully aggregated dynamically stats {self.dynamically_stats}')
        # exit with success from python script after saving
        sys.exit(0)

    async def call(self, url, session):
        """
        Make async call to API
        """
        async with session.get(url, headers=self.headers) as response:
            return await response.json()

    def fetch_single_stats(self):
        """
        Start async coroutine for fetching single stats
        """
        logger.info('Fetching single stats ...')
        loop = asyncio.get_event_loop()
        future = asyncio.ensure_future(self.get_single_stats())
        loop.run_until_complete(future)

    async def get_single_stats(self):
        single_container_url = f'{self.base_url}/api/v1/containers/{CONTAINER_NAME}'
        system_information_summary_url = f'{self.base_url}/api/v1/asset/info'
        single_storage_group_url = f'{self.base_url}/api/v1/storage/groups/DefaultGroup'
        async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
            tasks = [
                asyncio.ensure_future(self.call(single_container_url, session)),
                asyncio.ensure_future(self.call(system_information_summary_url, session)),
                asyncio.ensure_future(self.call(single_storage_group_url, session))
            ]
            single_container, system_information_summary, single_storage_group = await asyncio.gather(*tasks)
            self.single_stats['container_name'] = single_container.get('name')
            self.single_stats['protocol'] = single_container.get('protocol')
            self.single_stats['options'] = single_container.get('nas', {}).get('nfs', {}).get('options')
            self.single_stats['status'] = system_information_summary.get('systemState')
            self.single_stats['cleaner_status'] = system_information_summary.get('cleanerStatus')
            self.single_stats['compression'] = single_storage_group.get('compression')
            logger.info(f'Single stats: {self.single_stats}')

    def fetch_dynamically_stats(self):
        """
        Start async coroutine for fetching dynamically stats
        """
        logger.info('Fetching dynamically stats ...')
        loop = asyncio.get_event_loop()
        future = asyncio.ensure_future(self.get_dynamically_stats())
        loop.run_until_complete(future)

    async def get_dynamically_stats(self):
        storage_group_summary_url = f'{self.base_url}/api/v1/storage/groups/DefaultGroup?stats=true'
        throughput_chart_url = f'{self.base_url}/api/v1/charts/throughput?splits=1&range=300s'
        compression_chart_url = f'{self.base_url}/api/v1/charts/storage-savings?splits=1&range=300s'
        async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(ssl=False)) as session:
            tasks = [
                asyncio.ensure_future(self.call(storage_group_summary_url, session)),
                asyncio.ensure_future(self.call(throughput_chart_url, session)),
                asyncio.ensure_future(self.call(compression_chart_url, session))
            ]
            storage_group_summary, throughput_chart, compression_chart = await asyncio.gather(*tasks)
            stats = {
                'current_files': storage_group_summary.get('stats', {}).get('files', {}).get('filesCurrent'),
                'current_bytes': storage_group_summary.get('stats', {}).get('files', {}).get('bytesCurrent'),
                'write_throughput': throughput_chart.get('cur', {}).get('write'),
                'read_throughput': throughput_chart.get('cur', {}).get('read'),
                'dedupe': compression_chart.get('cur', {}).get('dedupe'),
                'compression': compression_chart.get('cur', {}).get('compression'),
                'total_savings': compression_chart.get('cur', {}).get('total')
            }
            timestamp = time.time()
            self.dynamically_stats[timestamp] = stats
            logger.info(f'Dynamically stats: {stats}')


def main():
    logger.info('Start fetching stats from Quest API')
    stats = Stats()
    stats.fetch_single_stats()
    while True:
        if time.time() > stats.finish:
            stats.save_and_exit()
        stats.fetch_dynamically_stats()
        time.sleep(SENDING_INTERVAL_IN_SECONDS)


if __name__ == '__main__':
    main()
