import os
import sys
import requests
import logging

QUEST_USERNAME = os.getenv('QUEST_USERNAME')
QUEST_PASSWORD = os.getenv('QUEST_PASSWORD')
QUEST_API_SCHEME = os.getenv('QUEST_API_SCHEME')
QUEST_API_HOST = os.getenv('QUEST_API_HOST')
QUEST_API_PORT = os.getenv('QUEST_API_PORT')
CONTAINER_NAME = os.getenv('CONTAINER_NAME')

API_BASE_URL = f'{QUEST_API_SCHEME}://{QUEST_API_HOST}:{QUEST_API_PORT}'


def setup_custom_logger(name=None):
    formatter = logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.addHandler(handler)
    return logger


logger = setup_custom_logger(__name__)


def get_jwt_token():
    url = f'{API_BASE_URL}/api/auth/login'
    response = requests.post(url, json={'name': QUEST_USERNAME, 'password': QUEST_PASSWORD}, verify=False)
    return response.json()['JWT_TOKEN']


def main():
    url = f'{API_BASE_URL}/api/v1/containers'
    token = get_jwt_token()
    payload = {
        'name': CONTAINER_NAME,
        'protocol': 'NAS',
        'storageGroup': 'DefaultGroup',
        'nas': {
            'marker': 'Auto',
            'protocols': ['NFS', 'CIFS'],
            'nfs': {
                'rootMapping': 'administrator',
                'options': 'rw',
                'clientAccess': 'open'
            },
            'cifs': {
                'clientAccess': 'open'
            }
        }
    }
    response = requests.post(url, json=payload, headers={'Authorization': f'Bearer {token}'}, verify=False)
    if response.status_code == 201:
        container_name = response.json()['name']
        logger.info(f'Successfully created container {container_name}')
        sys.exit(0)
    else:
        logger.info(f'Error during creating container {CONTAINER_NAME}. Status code: {response.status_code}')
        sys.exit(1)


if __name__ == '__main__':
    logger.info(f'Start creating quest container {CONTAINER_NAME}')
    main()
