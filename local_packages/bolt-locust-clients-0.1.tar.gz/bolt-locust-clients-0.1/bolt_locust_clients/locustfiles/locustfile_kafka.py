from os import getenv

from locust import TaskSet, task

from bolt_locust_clients.locust import KafkaLocust
from bolt_locust_clients.locustfiles.helpers import random_pos_data, random_hourly_data
from bolt_locust_clients.utils import KafkaPool

BROKER_HOST = getenv('BROKER_HOST', '34.244.197.15:9092')
MIN_WAIT = getenv('MIN_WAIT', '10')
MAX_WAIT = getenv('MAX_WAIT', '20')
KAFKA_POOL_SIZE = getenv('KAFKA_POOL_SIZE', '5')


class KafkaUser(TaskSet):
    @task(1)
    def add_hourly(self):
        self.client.send(topic='hourly_data', value=random_hourly_data())

    @task(1)
    def add_pos_data(self):
        self.client.send(topic='posdata', value=random_pos_data())

    def on_stop(self):
        self.client.kafka.flush()


class UserFlow(KafkaLocust):
    kafka_pool = KafkaPool(BROKER_HOST, int(KAFKA_POOL_SIZE))
    task_set = KafkaUser
    min_wait = int(MIN_WAIT)
    max_wait = int(MAX_WAIT)
