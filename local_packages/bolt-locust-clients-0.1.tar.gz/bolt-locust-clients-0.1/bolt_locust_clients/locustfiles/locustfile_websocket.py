from locust import TaskSet, task

from bolt_locust_clients.locust import WebSocketLocust


class WebSocketUser(TaskSet):
    token = None

    def on_start(self):
        self.token = self.auth_user()
        self.client.websocket_send({
            "callbackIndex": None,
            "class": "com.webaction.runtime.QueryValidator",
            "method": "setUpdateMode",
            "params": [True]
        })
        self.client.websocket_send({"callbackIndex": None,
                                    "class": "com.webaction.web.api.LicenseHelper",
                                    "method": "isIntercomEnabled",
                                    "params": []})
        self.client.websocket_send({"callbackIndex": None,
                                    "class": "com.webaction.security.WASecurityManager",
                                    "method": "isAuthenticated",
                                    "params": [self.token]})

    def auth_user(self):
        payload = {"username": "admin", "password": "admin"}
        self.client.http.headers["Content-Type"] = "application/x-www-form-urlencoded"
        token = self.client.http.post("/security/authenticate/", data=payload).json()['token']
        self.client.http.headers["Authorization"] = f"STRIIM-TOKEN {token}"
        self.client.http.headers["Content-Type"] = "application/json"
        return token

    def on_stop(self):
        self.client.close_connection()

    @task(5)
    def get_dashboards(self):
        self.client.websocket_send({
            "callbackIndex": None,
            "class": "com.webaction.runtime.QueryValidator",
            "method": "CRUDHandler",
            "params": [self.token, None, "READ", {"type": "DASHBOARD"}]
        }, timeout=2)


class WebsiteUser(WebSocketLocust):
    # def teardown(self):
    #    with ApiHelper() as api:
    #        api.clear_env()
    host = "https://striim.qa.acaisoft.io"
    ws_host = "wss://striim.qa.acaisoft.io/rmiws/"
    task_set = WebSocketUser
    min_wait = 40
    max_wait = 50
