import os

from locust import TaskSet, task

from bolt_locust_clients.locust import QuestFileSystemLocust
from bolt_locust_clients.enums import FileSizeEnum

MIN_WAIT = int(os.getenv('MIN_WAIT', '100'))
MAX_WAIT = int(os.getenv('MAX_WAIT', '200'))


class QuestTaskSet(TaskSet):
    @task(10)
    def send_small_file(self):
        self.client.write('File with size 1', FileSizeEnum.SIZE_1)

    @task(5)
    def send_normal_file(self):
        self.client.write('File with size 10', FileSizeEnum.SIZE_10)


class FileSystemUser(QuestFileSystemLocust):
    fs_host = '104.199.70.125'
    container_name = 'art'
    min_wait = MIN_WAIT
    max_wait = MAX_WAIT
    task_set = QuestTaskSet
