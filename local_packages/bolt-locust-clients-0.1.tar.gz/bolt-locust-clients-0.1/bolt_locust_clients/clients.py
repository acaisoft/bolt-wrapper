import _thread
import os
import ssl
import time
import random
import json
import libnfs

from subprocess import check_call, CalledProcessError
from threading import Thread
from typing import Dict
from locust import Locust, events, clients
from websocket import WebSocketApp

from .enums import FileSizeEnum
from .exceptions import (
    FileTypeException,
    FileSendingException,
    DDTToolException,
    BaseFyleSystemException,
    WebSocketClientException
)
from .logger import setup_custom_logger


absolute_dir_path = os.path.dirname(__file__)
logger = setup_custom_logger(__name__)


class FileSystemClient(object):
    """
    Common client for sending files to mounted file system directory
    """

    def __init__(self, host, container_name, mounted_path):
        self._nfs = libnfs.NFS(f'nfs://{host}/containers/{container_name}')
        self._mounted_path = mounted_path

    def _calculate_response_length(self, size: FileSizeEnum):
        _, length = size.name.split('_')
        return int(length)

    def _prepare_exception(self, ex, file_timestamp, func_name):
        # normalize exception body
        ex_body = str(ex)
        ex_body = ex_body.replace(f'-{file_timestamp}', '')  # normalize filename with uniq timestamp
        ex_body = ex_body.replace(f'{absolute_dir_path}/files/', '')  # normalize path to copied files
        ex_body = ex_body.replace(f'{absolute_dir_path}/quest/scripts/', '')  # normalize path to ddt tool
        ex_body = ex_body.replace(f'{self._mounted_path}/', '')  # normalize filename for ddt tool
        if func_name == 'send':
            return FileSendingException(ex_body)
        elif func_name == 'ddt':
            return DDTToolException(ex_body)
        else:
            return BaseFyleSystemException(ex_body)

    def _execute_command(self, name, command, length, file_timestamp, **kwargs):
        """
        Executing bash command
        """
        start_time = time.time()
        try:
            check_call(command, shell=True)
        except (CalledProcessError, Exception) as ex:
            total_time = int((time.time() - start_time) * 1000)
            func_name = kwargs.get('func_name')
            exception = self._prepare_exception(ex, file_timestamp, func_name)
            events.request_failure.fire(request_type='FS', name=name, response_time=total_time, exception=exception)
        else:
            total_time = int((time.time() - start_time) * 1000)
            events.request_success.fire(request_type='FS', name=name, response_time=total_time, response_length=length)

    def send(self, name, size: FileSizeEnum):
        """
        Copy dummy file to mounted file system directory
        """
        if type(size) is not FileSizeEnum:
            raise FileTypeException('Wrong file type for sending. Need to use FileSizeEnum.')
        file_timestamp = time.time()
        # copy file to mounted NFS directory
        command = f'cp {absolute_dir_path}/files/{size.value} {self._mounted_path}/{size.value}-{file_timestamp}'
        file_length = self._calculate_response_length(size)
        self._execute_command(
            name=name, command=command, length=file_length, file_timestamp=file_timestamp, func_name='send')

    def write(self, name, size: FileSizeEnum):
        """
        Create connection using libnfs and write bytes to file
        """
        length = self._calculate_response_length(size)  # mb
        data = bytearray(length * 1000 * 1000)  # bytes
        start_time = time.time()
        try:
            f = self._nfs.open(f'{start_time}', mode='w+')
            f.write(data)
        except Exception as ex:
            total_time = int((time.time() - start_time) * 1000)
            events.request_failure.fire(request_type='FS', name=name, response_time=total_time, exception=ex)
        else:
            total_time = int((time.time() - start_time) * 1000)
            events.request_success.fire(request_type='FS', name=name, response_time=total_time, response_length=length)
            f.close()


class QuestFileSystemClient(FileSystemClient):
    """
    Extended FileSystem client for Quest with ddt tool
    """

    def ddt(self, name, arguments: Dict):
        """
        Use ddt tool for creating file inside NFS directory
        Main ddt arguments:
            - filesize=<file size in MB | in K if "smallfiles=yes">
            - blocksize=<block size in KB>
            - dup-percentage=<0 - 100 | "zero" for zero data>
            - threads=<1 - 1024>
        """
        length = arguments['filesize'] if 'filesize' in arguments.keys() else 0  # mb
        if arguments.get('filesize') is None or arguments.get('blocksize') is None or arguments.get('filename') is None:
            raise FileTypeException('Arguments filename, filesize, blocksize required for ddt tool')
        # add absolute file path for filename
        default_filename = arguments.get('filename')
        file_timestamp = time.time()
        updated_filename = f'{self._mounted_path}/{default_filename}-{file_timestamp}'
        arguments['filename'] = updated_filename
        command = f'{absolute_dir_path}/quest/scripts/ddt'
        for key, value in arguments.items():
            command += f' {key}={value}'
        self._execute_command(
            name=name, command=command, length=int(length), file_timestamp=file_timestamp, func_name='ddt')


class WebSocketClient(object):
    """
    WebSocket client for locust
    """

    def __init__(self, host, ws_host):
        self.http = clients.HttpSession(host)
        self.ws_host = ws_host
        self.callback_index = 0
        self.ws = None
        self.started = False
        self._msg = []
        self.ws_thread = Thread(target=self.conn, args=())
        self.ws_thread.start()
        self.wait_for_connection()

    def close_connection(self):
        if self.ws is not None:
            self.ws.close()
        else:
            pass
        self.ws_thread.join()

    def wait_for_connection(self):
        cnt = 0
        while not self.started and cnt < 100:
            time.sleep(0.1)
            cnt += 1
        if not self.started:
            if self.ws is not None:
                self.ws.close()
            self.ws_thread.join()
            raise WebSocketClientException('WebSocket connection isn`t established')

    def conn(self):
        self.ws = WebSocketApp(
            self.ws_host,
            on_message=lambda ws, msg: self.on_message(ws, msg),
            on_error=lambda ws, msg: self.on_error(ws, msg),
            on_close=lambda ws: self.on_close(ws)
        )
        self.ws.on_open = lambda ws: self.on_open()
        self.ws.run_forever(sslopt={'cert_reqs': ssl.CERT_NONE})

    def on_error(self, ws, error):
        print(error)

    def on_close(self, ws):
        pass

    def on_open(self):
        def run():
            pass
        _thread.start_new_thread(run, ())
        self.started = True

    def on_message(self, ws, msg):
        self._msg.append(json.loads(msg))

    def send_message(self, message_dict):
        message_dict["callbackIndex"] = self.callback_index
        msg_ind = self.callback_index
        self.ws.send(json.dumps(message_dict))
        self.callback_index += 1
        return str(msg_ind)

    def get_message_by_id(self, callback_id, timeout=10):
        cnt = 0
        flag = True
        while flag and cnt < timeout * 10:
            try:
                msg = list(filter(lambda d: d['callbackIndex'] == callback_id, self._msg))[0]
                flag = False
                return msg
            except IndexError:
                time.sleep(0.1)
                cnt += 1
        return None

    def websocket_send(self, message, name=None, timeout=10):
        request_type = "WebSocket"
        start = time.time()
        if name is None:
            name = f"{message['class']}: {message['method']}"
        try:
            message_callback_id = self.send_message(message)
            response = self.get_message_by_id(message_callback_id, timeout=timeout)
        except Exception as e:
            total = int((time.time() - start) * 1000)
            events.request_failure.fire(
                request_type=request_type,
                name=name,
                response_time=total,
                exception=e
            )
        else:
            total = int((time.time() - start) * 1000)
            if response is not None:
                if response['success']:
                    events.request_success.fire(
                        request_type=request_type,
                        name=name,
                        response_time=total,
                        response_length=0
                    )
                else:
                    events.request_failure.fire(
                        request_type=request_type,
                        name=name,
                        response_time=total,
                        exception=','.join(response['params'])
                    )
            else:
                events.request_failure.fire(
                    request_type=request_type,
                    name=name,
                    response_time=total,
                    exception=f"Response Timeout after {timeout} seconds."
                )


class FileSystemLocustBase(Locust):
    """
    Base class for locust user
    """
    host = None
    client_class = None
    container_name = None

    mounts = [v for k, v in os.environ.items() if k.startswith('BOLT_NFS_MOUNT_')]

    def __init__(self):
        super(FileSystemLocustBase, self).__init__()
        mounted_path = random.choice(self.mounts)
        self.client = self.client_class(host=self.host, container_name=self.container_name, mounted_path=mounted_path)
        logger.info(f'Successfully created locust user with mounted path {mounted_path}')


class WebSocketLocust(Locust):
    """
    WebSocket instance of locust user
    """
    ws_host = None

    def __init__(self):
        super(WebSocketLocust, self).__init__()
        self.client = WebSocketClient(host=self.host, ws_host=self.ws_host)
        logger.info(f'Successfully created web socket locust user {id(self)}')


class FileSystemLocust(FileSystemLocustBase):
    """
    Common instance of locust user
    """
    client_class = FileSystemClient


class QuestFileSystemLocust(FileSystemLocustBase):
    """
    Quest instance of locust user
    """
    client_class = QuestFileSystemClient
