import os
import time
import random

from subprocess import check_call, CalledProcessError, Popen
from typing import Dict
from locust import Locust, events

from .enums import FileSizeEnum
from .exceptions import FileTypeException, FileSendingException, DDTToolException, BaseFyleSystemException
from .logger import setup_custom_logger

absolute_dir_path = os.path.dirname(__file__)
logger = setup_custom_logger(__name__)


class FileSystemClient(object):
    """
    Common client for sending files to mounted file system directory
    """
    def __init__(self, mounted_path):
        self._mounted_path = mounted_path

    def _calculate_response_length(self, size: FileSizeEnum):
        _, length = size.name.split('_')
        return int(length)

    def _prepare_exception(self, ex, file_timestamp, func_name):
        # normalize exception body
        ex_body = str(ex)
        ex_body = ex_body.replace(f'-{file_timestamp}', '')  # normalize filename with uniq timestamp
        ex_body = ex_body.replace(f'{absolute_dir_path}/files/', '')  # normalize path to copied files
        ex_body = ex_body.replace(f'{absolute_dir_path}/quest/scripts/', '')  # normalize path to ddt tool
        ex_body = ex_body.replace(f'{self._mounted_path}/', '')  # normalize filename for ddt tool
        if func_name == 'send':
            return FileSendingException(ex_body)
        elif func_name == 'ddt':
            return DDTToolException(ex_body)
        else:
            return BaseFyleSystemException(ex_body)

    def _execute_command(self, name, command, length, file_timestamp, **kwargs):
        """
        Executing bash command
        """
        start_time = time.time()
        try:
            check_call(command, shell=True)
        except (CalledProcessError, Exception) as ex:
            total_time = int((time.time() - start_time) * 1000)
            func_name = kwargs.get('func_name')
            exception = self._prepare_exception(ex, file_timestamp, func_name)
            events.request_failure.fire(request_type='NFS', name=name, response_time=total_time, exception=exception)
        else:
            total_time = int((time.time() - start_time) * 1000)
            events.request_success.fire(request_type='NFS', name=name, response_time=total_time, response_length=length)

    def send(self, name, size: FileSizeEnum):
        """
        Copy dummy file to mounted file system directory
        """
        if type(size) is not FileSizeEnum:
            raise FileTypeException('Wrong file type for sending. Need to use FileSizeEnum.')
        file_timestamp = time.time()
        # copy file to mounted NFS directory
        command = f'cp {absolute_dir_path}/files/{size.value} {self._mounted_path}/{size.value}-{file_timestamp}'
        file_length = self._calculate_response_length(size)
        self._execute_command(
            name=name, command=command, length=file_length, file_timestamp=file_timestamp, func_name='send')


class QuestFileSystemClient(FileSystemClient):
    """
    Extended FileSystem client for Quest with ddt tool
    """
    def ddt(self, name, arguments: Dict):
        """
        Use ddt tool for creating file inside NFS directory
        Main ddt arguments:
            - filesize=<file size in MB | in K if "smallfiles=yes">
            - blocksize=<block size in KB>
            - dup-percentage=<0 - 100 | "zero" for zero data>
            - threads=<1 - 1024>
        """
        length = arguments['filesize'] if 'filesize' in arguments.keys() else 0  # mb
        if arguments.get('filesize') is None or arguments.get('blocksize') is None or arguments.get('filename') is None:
            raise FileTypeException('Arguments filename, filesize, blocksize required for ddt tool')
        # add absolute file path for filename
        default_filename = arguments.get('filename')
        file_timestamp = time.time()
        updated_filename = f'{self._mounted_path}/{default_filename}-{file_timestamp}'
        arguments['filename'] = updated_filename
        command = f'{absolute_dir_path}/quest/scripts/ddt'
        for key, value in arguments.items():
            command += f' {key}={value}'
        self._execute_command(
            name=name, command=command, length=int(length), file_timestamp=file_timestamp, func_name='ddt')


class FileSystemLocustBase(Locust):
    """
    Base class for locust user
    """
    client_class = None
    mounts = None

    def __init__(self):
        super(FileSystemLocustBase, self).__init__()
        mounted_path = self.mounted_path
        self.client = self.client_class(mounted_path=mounted_path)
        logger.info(f'Successfully created locust user with mounted path {mounted_path}')

    @property
    def mounted_path(self):
        return random.choice(self.mounts)

    @staticmethod
    def run_python(path, args=None, wait=False):
        """
        Running additional python scripts
        """
        cmd = ['python3', path]
        if args is not None:
            cmd.extend(args)
        if wait:
            Popen(cmd).wait()
        else:
            Popen(cmd)


class FileSystemLocust(FileSystemLocustBase):
    """
    Common instance of locust user
    """
    client_class = FileSystemClient


class QuestFileSystemLocust(FileSystemLocustBase):
    """
    Quest instance of locust user
    """
    client_class = QuestFileSystemClient
