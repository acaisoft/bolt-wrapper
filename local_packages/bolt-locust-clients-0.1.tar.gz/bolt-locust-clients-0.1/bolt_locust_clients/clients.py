import os
import time

from subprocess import check_call, CalledProcessError, Popen
from typing import Dict
from locust import Locust, events

from .enums import FileSizeEnum
from .exceptions import FileTypeException, NFSException
from .logger import setup_custom_logger

absolute_dir_path = os.path.dirname(__file__)
logger = setup_custom_logger(__name__)


class NFSClient(object):
    """
    Common client for sending files to mounted NFS directory
    """
    def __init__(self, mounted_path):
        self._mounted_path = mounted_path

    def _calculate_response_length(self, size: FileSizeEnum):
        _, length = size.name.split('_')
        return int(length)

    def _execute_command(self, name, command, length, *args):
        """
        Executing bash command
        """
        start_time = time.time()
        try:
            check_call(command, shell=True, *args)
        except (CalledProcessError, Exception):
            total_time = int((time.time() - start_time) * 1000)
            ex = NFSException('Sending error')  # use common exception without trash
            events.request_failure.fire(request_type='NFS', name=name, response_time=total_time, exception=ex)
        else:
            total_time = int((time.time() - start_time) * 1000)
            events.request_success.fire(request_type='NFS', name=name, response_time=total_time, response_length=length)

    def send(self, name, size: FileSizeEnum, *args):
        """
        Copy dummy file to mounted NFS directory
        """
        if type(size) is not FileSizeEnum:
            raise FileTypeException('Wrong file type for sending. Need to use FileSizeEnum.')
        # copy file to mounted NFS directory
        command = f'cp {absolute_dir_path}/files/{size.value} {self._mounted_path}/{size.value}-{time.time()}'
        file_length = self._calculate_response_length(size)
        self._execute_command(name=name, command=command, length=file_length, *args)


class QuestNFSClient(NFSClient):
    """
    Extended NFS client for Quest with ddt tool
    """
    def ddt(self, name, arguments: Dict, *args):
        """
        Use ddt tool for creating file inside NFS directory
        Main ddt arguments:
            - filesize=<file size in MB | in K if "smallfiles=yes">
            - blocksize=<block size in KB>
            - dup-percentage=<0 - 100 | "zero" for zero data>
            - threads=<1 - 1024>
        """
        length = arguments['filesize'] if 'filesize' in arguments.keys() else 0  # mb
        if arguments.get('filesize') is None or arguments.get('blocksize') is None or arguments.get('filename') is None:
            raise FileTypeException('Arguments filename, filesize, blocksize required for ddt tool')
        # add absolute file path for filename
        default_filename = arguments.get('filename')
        updated_filename = f'{self._mounted_path}/{default_filename}_{time.time()}'
        arguments['filename'] = updated_filename
        command = f'{absolute_dir_path}/quest/scripts/ddt'
        for key, value in arguments.items():
            command += f' {key}={value}'
        self._execute_command(name=name, command=command, length=int(length), *args)


class NFSLocustBase(Locust):
    """
    Base class for locust user
    """
    client_class = None
    mounted_path = None

    def __init__(self):
        super(NFSLocustBase, self).__init__()
        self.client = self.client_class(mounted_path=self.mounted_path)

    @staticmethod
    def run_python(path, args=None, wait=False):
        """
        Running additional python scripts
        """
        cmd = ['python3', path]
        if args is not None:
            cmd.extend(args)
        if wait:
            Popen(cmd).wait()
        else:
            Popen(cmd)


class NFSLocust(NFSLocustBase):
    """
    Common instance of locust user
    """
    client_class = NFSClient


class QuestNFSLocust(NFSLocustBase):
    """
    Quest instance of locust user
    """
    client_class = QuestNFSClient
