import time
import libnfs

from threading import Thread


def call():
    print('1')
    nfs = libnfs.NFS('nfs://192.168.1.201/containers/aaa')
    print('2')
    time.sleep(250)
    a = nfs.open(f'new_test_file_1g_{time.time()}.txt', mode='w+')
    print('3')
    data = bytearray(50000000)
    print('4')
    a.write(data)
    print('5')
    a.close()
    print('6')


if __name__ == '__main__':
    call()
