import os
import random

from locust import Locust

from .logger import setup_custom_logger
from .clients import WebSocketClient, KafkaClient, FileSystemClient, QuestFileSystemClient

absolute_dir_path = os.path.dirname(__file__)
logger = setup_custom_logger(__name__)


class FileSystemLocustBase(Locust):
    """
    Base File System class for locust user
    """
    host = None
    fs_host = None
    client_class = None
    container_name = None

    mounts = [v for k, v in os.environ.items() if k.startswith('BOLT_NFS_MOUNT_')]

    def __init__(self):
        super(FileSystemLocustBase, self).__init__()
        mounted_path = random.choice(self.mounts)
        logger.info(f'FileSystem arguments: {mounted_path} | {self.container_name} | {self.fs_host}')
        self.client = self.client_class(
            fs_host=self.fs_host, container_name=self.container_name, mounted_path=mounted_path)
        logger.info(f'Successfully created locust user with mounted path {mounted_path}')


class WebSocketLocust(Locust):
    """
    WebSocket instance of locust user
    """
    ws_host = None

    def __init__(self):
        super(WebSocketLocust, self).__init__()
        self.client = WebSocketClient(host=self.host, ws_host=self.ws_host)
        logger.info(f'Successfully created web socket locust user {id(self)}')


class FileSystemLocust(FileSystemLocustBase):
    """
    Common File System instance of locust user
    """
    client_class = FileSystemClient


class QuestFileSystemLocust(FileSystemLocustBase):
    """
    Quest instance of locust user
    """
    client_class = QuestFileSystemClient


class KafkaLocust(Locust):
    """
    Kafka instance of locust user
    """
    broker_address = None
    buffer_memory = 33554432

    def __init__(self):
        super(KafkaLocust, self).__init__()
        self.client = KafkaClient(host=self.host, broker_address=self.broker_address, buffer_memory=self.buffer_memory)
        logger.info(f'Successfully created kafka locust user | Host: {self.host} | Broker {self.broker_address}')
