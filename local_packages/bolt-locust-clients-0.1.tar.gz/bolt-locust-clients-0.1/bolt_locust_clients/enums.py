from enum import Enum


class FileSizeEnum(Enum):
    SIZE_1 = '1mb'
    SIZE_10 = '10mb'
    SIZE_100 = '100mb'
