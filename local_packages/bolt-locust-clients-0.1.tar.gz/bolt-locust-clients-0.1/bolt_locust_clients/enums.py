from enum import Enum


class FileSizeEnum(Enum):
    SIZE_1 = '1mb'
    SIZE_1_NEW = '1mb_new'
    SIZE_10 = '10mb'
    SIZE_10_NEW = '10mb_new'
    SIZE_100 = '100mb'
    SIZE_100_NEW = '100mb_new'
