import os

from locust import TaskSet, task

from bolt_locust_clients.clients import QuestFileSystemLocust
from bolt_locust_clients.enums import FileSizeEnum

BOLT_NFS_MOUNT = os.getenv('BOLT_NFS_MOUNT_1')
STATS_DURATION = os.getenv('STATS_DURATION')
MIN_WAIT = int(os.getenv('MIN_WAIT', '100'))
MAX_WAIT = int(os.getenv('MAX_WAIT', '200'))

absolute_dir_path = os.path.dirname(__file__)
mounts = [v for k, v in os.environ.items() if k.startswith('BOLT_NFS_MOUNT_')]


class QuestTaskSet(TaskSet):
    @task(10)
    def send_small_file(self):
        self.client.send('File with size 1', FileSizeEnum.SIZE_1)

    @task(5)
    def send_normal_file(self):
        self.client.send('Another file with size 1', FileSizeEnum.SIZE_1)

    @task(3)
    def send_normal_file(self):
        self.client.send('File with size 10', FileSizeEnum.SIZE_10)

    @task(1)
    def send_big_file(self):
        self.client.send('File with size 100', FileSizeEnum.SIZE_100)

    @task(1)
    def generate_small_ddt(self):
        self.client.ddt('Small ddt', {'filename': 'small_ddt', 'filesize': '10', 'blocksize': '8'})

    @task(1)
    def generate_big_ddt(self):
        ddt_arguments = {
            'op': 'write', 'filename': 'big_ddt_file', 'filesize': '1024',
            'blocksize': '8', 'buffering': 'system', 'dup-percentage': '90', 'compression': '25',
            'io': 'sequential', 'contents': 'binary', 'threads': '1', 'checksum': 'yes', 'seed': '343030077'
        }
        self.client.ddt('Big ddt', ddt_arguments)


class FileSystemUser(QuestFileSystemLocust):
    mounts = mounts
    min_wait = MIN_WAIT
    max_wait = MAX_WAIT
    task_set = QuestTaskSet

