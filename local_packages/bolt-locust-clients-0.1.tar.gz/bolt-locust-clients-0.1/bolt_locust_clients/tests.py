from time import sleep
import signal
import sys


def _exit_with_success(signo, stack_frame):
    print(signo)
    print(stack_frame)
    sys.exit(0)


signal.signal(signal.SIGINT, _exit_with_success)
signal.signal(signal.SIGTERM, _exit_with_success)
signal.signal(signal.SIGABRT, _exit_with_success)
signal.signal(signal.SIGQUIT, _exit_with_success)
try:
    sleep(1000)
finally:
    print('byyyyyyyyyy')
