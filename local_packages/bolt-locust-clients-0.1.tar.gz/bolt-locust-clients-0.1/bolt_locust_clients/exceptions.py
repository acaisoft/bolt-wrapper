class FileTypeException(Exception):
    pass


class BaseFyleSystemException(Exception):
    pass


class FileSendingException(BaseFyleSystemException):
    pass


class DDTToolException(BaseFyleSystemException):
    pass
