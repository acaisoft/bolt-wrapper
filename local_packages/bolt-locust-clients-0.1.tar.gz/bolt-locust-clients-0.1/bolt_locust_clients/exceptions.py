class FileTypeException(Exception):
    pass


class FileSystemException(Exception):
    pass
