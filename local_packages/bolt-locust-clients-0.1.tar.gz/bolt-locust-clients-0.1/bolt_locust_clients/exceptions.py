class FileTypeException(Exception):
    pass


class NFSException(Exception):
    pass
