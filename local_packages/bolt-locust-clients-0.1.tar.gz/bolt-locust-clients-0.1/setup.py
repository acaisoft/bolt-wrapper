from setuptools import setup

setup(
    name='bolt-locust-clients',
    version='0.1',
    packages=['bolt_locust_clients'],
    package_data={
        'bolt_locust_clients': ['files/*', 'quest/*', 'quest/scripts/*', 'locustfiles/*']
    },
    url='https://bitbucket.org/acaisoft/bolt-locust-clients/',
    license='',
    author='artiom.borysiewicz',
    author_email='artiom.borysiewicz@acaisoft.com',
    description='',
    install_requires=[
        'locustio==0.11.0',
        'aiohttp==3.5.4',
        'websocket-client==0.56.0',
        'kafka-python==1.4.6',
        'libnfs==1.0.post4'
    ]
)
