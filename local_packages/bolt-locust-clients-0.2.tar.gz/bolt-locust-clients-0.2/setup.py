from setuptools import setup

setup(
    name='bolt-locust-clients',
    version='0.2',
    packages=['bolt_locust_clients'],
    package_data={
        'bolt_locust_clients': ['files/*', 'quest/*', 'quest/scripts/*', 'locustfiles/*']
    },
    url='https://bitbucket.org/acaisoft/bolt-locust-clients/',
    license='',
    author='artiom.borysiewicz',
    author_email='artiom.borysiewicz@acaisoft.com',
    description='',
    install_requires=[
        'aiohttp==3.6.2',
        'gevent==1.4.0',
        'kafka-python==1.4.7',
        'libnfs==1.0.post4',
        'locustio==0.13.5',
        'websocket-client==0.57.0',
    ]
)
