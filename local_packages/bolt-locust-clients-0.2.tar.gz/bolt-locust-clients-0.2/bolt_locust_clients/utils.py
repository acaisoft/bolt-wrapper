from itertools import cycle

from bolt_locust_clients.clients import KafkaClient


class KafkaPool(object):
    """
    Helper class for creating a predefined pool of producers
    """
    producers: list
    next_producer = None

    def __init__(self, broker_address, pull_size, host=None):
        self.producers = cycle([KafkaClient(broker_address=broker_address, host=host) for _ in range(pull_size)])
        self.next_producer = next(self.producers)

    def producer(self):
        current_producer, self.next_producer = self.next_producer, next(self.producers)
        return current_producer
