from setuptools import setup

setup(
    name='bolt-locust-clients',
    version='0.8',
    packages=['bolt_locust_clients'],
    package_data={
        'bolt_locust_clients': ['files/*', 'quest/*', 'quest/scripts/*', 'locustfiles/*']
    },
    url='https://bitbucket.org/acaisoft/bolt-locust-clients/',
    license='',
    author='artiom.borysiewicz',
    author_email='artiom.borysiewicz@acaisoft.com',
    description='',
    install_requires=[
        'gql==0.1.0',
        'graphql-core==2.3.1',
        'locustio==0.14.6',
        'msgpack==0.6.2',
        'python-dateutil==2.8.0',
        'websocket-client==0.56.0',
        'aiohttp==3.5.4',
        'websocket-client==0.56.0',
        'kafka-python==1.4.6',
        'libnfs==1.0.post4',
    ]
)
# TODO: edit requirements
