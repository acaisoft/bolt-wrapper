class WebSocketClientException(Exception):
    pass


class FileTypeException(Exception):
    pass


class BaseFileSystemException(Exception):
    pass


class FileSendingException(BaseFileSystemException):
    pass


class DDTToolException(BaseFileSystemException):
    pass
